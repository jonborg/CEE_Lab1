function anim_arm(t, p, g, L)
%
% Flexible Arm animation
%
% t: Nx1 : time
% p: Nx1 : potentiometer (rad)
% g: Nx1 : strain gage (rad)
% L: 1x1 : length of the bar

% March 2016, J. Gaspar

if nargin<1
    t= evalin('base','t');
    ssx= evalin('base','ssx');
    p= ssx(:,1);
    g= ssx(:,2);
    L= 1;
end

if 0
    figure(202); clf;
    plot(t,p, t,g)
end

t1= min(t); t2= max(t); ti= (0:1e-3:1)*(t2-t1)+t1;
yi= interp1(t, [p(:) g(:)], ti);
k= 1;
anim_arm_main(ti, k*yi(:,1), k*yi(:,2), L)

return


function anim_arm_main(t, p, g, L)

figure(203); clf; %hold on
for i=1:length(t)
    x= draw_arm(p(i), g(i), L);
    plot(x(1,:), x(2,:), '.-');
    axis([0 1 -1 1])
    drawnow
end


function p= draw_arm(alpha, beta, L)
N= 10;
%L= 1;
v= [L/N 0]';

ca= cos(alpha); sa= sin(alpha);
Ra= [ca -sa; sa ca];

cb= cos(beta/N); sb= sin(beta/N);
Rb= [cb -sb; sb cb];

v= Ra*v;
p= [0 0]';
for i=1:N
    p= [p p(:,end)+Rb*v];
end