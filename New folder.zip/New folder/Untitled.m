A=[0 0 1 0; 0 0 0 1; 0 566 -37 0; 0 -922 37 0];
b=[0 0 65 -65]';
c=[1 1 0 0];

AA=[A zeros(4,1); C 0];
bb=[b; 0]
kk=[K  k1]



alphaK=poly([-70 -20 -10 -10]);

a=poly(AA-b*kk);

CM=controlability(A,b);
OM=observability(A,c);
M=[1 0 0 0; a(2) 1 0 0; a(3) a(2) 1 0; a(4) a(3) a(2) 1];

K=(alphaK(2:5)-a(2:5))*inv(M)'*inv(CM)
