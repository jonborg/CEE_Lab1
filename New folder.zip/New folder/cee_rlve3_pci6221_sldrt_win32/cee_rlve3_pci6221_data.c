/*
 * cee_rlve3_pci6221_data.c
 *
 * Code generation for model "cee_rlve3_pci6221".
 *
 * Model version              : 1.36
 * Simulink Coder version : 8.8 (R2015a) 09-Feb-2015
 * C source code generated on : Wed May 11 17:59:48 2016
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "cee_rlve3_pci6221.h"
#include "cee_rlve3_pci6221_private.h"

/* Block parameters (auto storage) */
P_cee_rlve3_pci6221_T cee_rlve3_pci6221_P = {
  /*  Variable: A2
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 566.0, -922.0, 0.0, 1.0, 0.0, -37.0, 37.0,
    0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 65.0, -65.0, 0.0 },

  /*  Variable: K
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 302.50648228176146, -857.83197925670015, 15.982886776145193,
    -35.201728608470177, 123.00000000000014 },
  0.052631578947368418,                /* Variable: K_GAGE
                                        * Referenced by: '<Root>/Ganho Calib Gage'
                                        */
  -0.614355896702004,                  /* Variable: K_POT
                                        * Referenced by: '<Root>/Ganho Calib Pot'
                                        */

  /*  Variable: L
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 394.38483146067455, -241.38483146067449, -157.46910112358512,
    7774.4691011235946, 2917.0267934312983 },
  1.0,                                 /* Variable: strain_gauge_gain_after_offset
                                        * Referenced by: '<S1>/soft calib gain'
                                        */
  0.0,                                 /* Variable: strain_gauge_offset
                                        * Referenced by: '<S1>/soft remove offset'
                                        */
  0.0,                                 /* Mask Parameter: TensaoMotor_FinalValue
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  0.0,                                 /* Mask Parameter: TensaoMotor_InitialValue
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  10.0,                                /* Mask Parameter: TensaoMotor_MaxMissedTicks
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  10.0,                                /* Mask Parameter: Potenciometroeextensometro_MaxM
                                        * Referenced by: '<S1>/Potenciometro e  extensometro'
                                        */
  0.0,                                 /* Mask Parameter: TensaoMotor_YieldWhenWaiting
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  0.0,                                 /* Mask Parameter: Potenciometroeextensometro_Yiel
                                        * Referenced by: '<S1>/Potenciometro e  extensometro'
                                        */
  0,                                   /* Mask Parameter: TensaoMotor_Channels
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */

  /*  Mask Parameter: Potenciometroeextensometro_Chan
   * Referenced by: '<S1>/Potenciometro e  extensometro'
   */
  { 0, 1 },
  0,                                   /* Mask Parameter: TensaoMotor_RangeMode
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  0,                                   /* Mask Parameter: Potenciometroeextensometro_Rang
                                        * Referenced by: '<S1>/Potenciometro e  extensometro'
                                        */
  0,                                   /* Mask Parameter: TensaoMotor_VoltRange
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  0,                                   /* Mask Parameter: Potenciometroeextensometro_Volt
                                        * Referenced by: '<S1>/Potenciometro e  extensometro'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/CONTROLADOR'
                                        */
  5.0,                                 /* Expression: 5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  -5.0,                                /* Expression: -5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Constant'
                                        */

  /*  Computed Parameter: PREFILTRO_A
   * Referenced by: '<Root>/PRE FILTRO'
   */
  { -14.0, -49.0 },

  /*  Computed Parameter: PREFILTRO_C
   * Referenced by: '<Root>/PRE FILTRO'
   */
  { 0.0, 52.92 },
  30.0,                                /* Expression: 30
                                        * Referenced by: '<Root>/referencia'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<Root>/referencia'
                                        */
  0.017453292519943295,                /* Expression: pi/180
                                        * Referenced by: '<Root>/Radianos'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Const2'
                                        */

  /*  Computed Parameter: Filtro_A
   * Referenced by: '<Root>/Filtro'
   */
  { -40.0, -400.0 },

  /*  Computed Parameter: Filtro_C
   * Referenced by: '<Root>/Filtro'
   */
  { 0.0, 400.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Integrator'
                                        */
  1U,                                  /* Computed Parameter: SwitchFiltro_CurrentSetting
                                        * Referenced by: '<Root>/Switch  Filtro'
                                        */
  1U,                                  /* Computed Parameter: SwitchOutput_CurrentSetting
                                        * Referenced by: '<Root>/Switch Output'
                                        */
  1U,                                  /* Computed Parameter: SwitchPreFiltro_CurrentSetting
                                        * Referenced by: '<Root>/Switch  Pre-Filtro'
                                        */
  1U                                   /* Computed Parameter: SwitchExtensometro_CurrentSetti
                                        * Referenced by: '<Root>/Switch Extensometro'
                                        */
};

/* Constant parameters (auto storage) */
const ConstP_cee_rlve3_pci6221_T cee_rlve3_pci6221_ConstP = {
  /* Expression: A2-b2*K-L*c2
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 0.0, 0.0, 0.0, 0.0, 302.50648228176146, 0.0, 0.0, 0.0, 0.0,
    -857.83197925670015, 0.0, 0.0, 0.0, 0.0, 15.982886776145193, 0.0, 0.0, 0.0,
    0.0, -35.201728608470177, 0.0, 0.0, 0.0, 0.0, 123.00000000000014 },

  /* Expression: A2-b2*K-L*c2
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 394.38483146067455, -241.38483146067449, -157.46910112358512,
    7774.4691011235946, 2917.0267934312983, 394.38483146067455,
    -241.38483146067449, -157.46910112358512, 7774.4691011235946,
    2917.0267934312983, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 }
};
