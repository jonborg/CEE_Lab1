/*
 * cee_rlve3_pci6221.c
 *
 * Code generation for model "cee_rlve3_pci6221".
 *
 * Model version              : 1.36
 * Simulink Coder version : 8.8 (R2015a) 09-Feb-2015
 * C source code generated on : Wed May 11 17:59:48 2016
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "cee_rlve3_pci6221.h"
#include "cee_rlve3_pci6221_private.h"
#include "cee_rlve3_pci6221_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double RTWinBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int RTWinTimerCount = 1;
const double RTWinTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int RTWinBoardCount = 1;
RTWINBOARD RTWinBoards[1] = {
  { "National_Instruments/PCI-6221", 4294967295U, 5, RTWinBoardOptions0 },
};

/* Block signals (auto storage) */
B_cee_rlve3_pci6221_T cee_rlve3_pci6221_B;

/* Continuous states */
X_cee_rlve3_pci6221_T cee_rlve3_pci6221_X;

/* Block states (auto storage) */
DW_cee_rlve3_pci6221_T cee_rlve3_pci6221_DW;

/* Real-time model */
RT_MODEL_cee_rlve3_pci6221_T cee_rlve3_pci6221_M_;
RT_MODEL_cee_rlve3_pci6221_T *const cee_rlve3_pci6221_M = &cee_rlve3_pci6221_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 10;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  cee_rlve3_pci6221_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  cee_rlve3_pci6221_output();
  cee_rlve3_pci6221_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  cee_rlve3_pci6221_output();
  cee_rlve3_pci6221_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void cee_rlve3_pci6221_output(void)
{
  /* local block i/o variables */
  real_T rtb_Potenciometroeextensometro[2];
  int_T ci;
  real_T rtb_PREFILTRO;
  if (rtmIsMajorTimeStep(cee_rlve3_pci6221_M)) {
    /* set solver stop time */
    if (!(cee_rlve3_pci6221_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&cee_rlve3_pci6221_M->solverInfo,
                            ((cee_rlve3_pci6221_M->Timing.clockTickH0 + 1) *
        cee_rlve3_pci6221_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&cee_rlve3_pci6221_M->solverInfo,
                            ((cee_rlve3_pci6221_M->Timing.clockTick0 + 1) *
        cee_rlve3_pci6221_M->Timing.stepSize0 +
        cee_rlve3_pci6221_M->Timing.clockTickH0 *
        cee_rlve3_pci6221_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(cee_rlve3_pci6221_M)) {
    cee_rlve3_pci6221_M->Timing.t[0] = rtsiGetT(&cee_rlve3_pci6221_M->solverInfo);
  }

  /* StateSpace: '<Root>/CONTROLADOR' */
  rtb_PREFILTRO = 0.0;
  for (ci = 0; ci < 5; ci++) {
    rtb_PREFILTRO += cee_rlve3_pci6221_P.K[ci] *
      cee_rlve3_pci6221_X.CONTROLADOR_CSTATE[ci];
  }

  /* End of StateSpace: '<Root>/CONTROLADOR' */

  /* Saturate: '<Root>/Saturation' */
  if (rtb_PREFILTRO > cee_rlve3_pci6221_P.Saturation_UpperSat) {
    cee_rlve3_pci6221_B.Saturation = cee_rlve3_pci6221_P.Saturation_UpperSat;
  } else if (rtb_PREFILTRO < cee_rlve3_pci6221_P.Saturation_LowerSat) {
    cee_rlve3_pci6221_B.Saturation = cee_rlve3_pci6221_P.Saturation_LowerSat;
  } else {
    cee_rlve3_pci6221_B.Saturation = rtb_PREFILTRO;
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* ManualSwitch: '<Root>/Switch Output' incorporates:
   *  Constant: '<Root>/Constant'
   */
  if (cee_rlve3_pci6221_P.SwitchOutput_CurrentSetting == 1) {
    cee_rlve3_pci6221_B.SwitchOutput = cee_rlve3_pci6221_B.Saturation;
  } else {
    cee_rlve3_pci6221_B.SwitchOutput = cee_rlve3_pci6221_P.Constant_Value;
  }

  /* End of ManualSwitch: '<Root>/Switch Output' */
  if (rtmIsMajorTimeStep(cee_rlve3_pci6221_M)) {
    /* S-Function Block: <Root>/Tensao Motor */
    {
      {
        ANALOGIOPARM parm;
        parm.mode = (RANGEMODE) cee_rlve3_pci6221_P.TensaoMotor_RangeMode;
        parm.rangeidx = cee_rlve3_pci6221_P.TensaoMotor_VoltRange;
        RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                       &cee_rlve3_pci6221_P.TensaoMotor_Channels,
                       &cee_rlve3_pci6221_B.SwitchOutput, &parm);
      }
    }

    /* S-Function Block: <S1>/Potenciometro e  extensometro */
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        cee_rlve3_pci6221_P.Potenciometroeextensometro_Rang;
      parm.rangeidx = cee_rlve3_pci6221_P.Potenciometroeextensometro_Volt;
      RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2,
                     cee_rlve3_pci6221_P.Potenciometroeextensometro_Chan,
                     &rtb_Potenciometroeextensometro[0], &parm);
    }

    /* Gain: '<Root>/Ganho Calib Gage' incorporates:
     *  Constant: '<S1>/soft remove offset'
     *  Gain: '<S1>/soft calib gain'
     *  Sum: '<S1>/Sum'
     */
    cee_rlve3_pci6221_B.GanhoCalibGage = (rtb_Potenciometroeextensometro[1] -
      cee_rlve3_pci6221_P.strain_gauge_offset) *
      cee_rlve3_pci6221_P.strain_gauge_gain_after_offset *
      cee_rlve3_pci6221_P.K_GAGE;

    /* Gain: '<Root>/Ganho Calib Pot' */
    cee_rlve3_pci6221_B.GanhoCalibPot = cee_rlve3_pci6221_P.K_POT *
      rtb_Potenciometroeextensometro[0];
  }

  /* SignalGenerator: '<Root>/referencia' */
  rtb_PREFILTRO = cee_rlve3_pci6221_P.referencia_Frequency *
    cee_rlve3_pci6221_M->Timing.t[0];
  if (rtb_PREFILTRO - floor(rtb_PREFILTRO) >= 0.5) {
    rtb_PREFILTRO = cee_rlve3_pci6221_P.referencia_Amplitude;
  } else {
    rtb_PREFILTRO = -cee_rlve3_pci6221_P.referencia_Amplitude;
  }

  /* End of SignalGenerator: '<Root>/referencia' */

  /* Gain: '<Root>/Radianos' */
  cee_rlve3_pci6221_B.Radianos = cee_rlve3_pci6221_P.Radianos_Gain *
    rtb_PREFILTRO;

  /* ManualSwitch: '<Root>/Switch  Pre-Filtro' incorporates:
   *  TransferFcn: '<Root>/PRE FILTRO'
   */
  if (cee_rlve3_pci6221_P.SwitchPreFiltro_CurrentSetting == 1) {
    cee_rlve3_pci6221_B.SwitchPreFiltro = cee_rlve3_pci6221_P.PREFILTRO_C[0] *
      cee_rlve3_pci6221_X.PREFILTRO_CSTATE[0] + cee_rlve3_pci6221_P.PREFILTRO_C
      [1] * cee_rlve3_pci6221_X.PREFILTRO_CSTATE[1];
  } else {
    cee_rlve3_pci6221_B.SwitchPreFiltro = cee_rlve3_pci6221_B.Radianos;
  }

  /* End of ManualSwitch: '<Root>/Switch  Pre-Filtro' */
  if (rtmIsMajorTimeStep(cee_rlve3_pci6221_M)) {
  }

  /* Integrator: '<Root>/Integrator' */
  cee_rlve3_pci6221_B.Integrator = cee_rlve3_pci6221_X.Integrator_CSTATE;

  /* ManualSwitch: '<Root>/Switch Extensometro' incorporates:
   *  Constant: '<Root>/Const2'
   *  ManualSwitch: '<Root>/Switch  Filtro'
   */
  if (cee_rlve3_pci6221_P.SwitchExtensometro_CurrentSetti == 1) {
    rtb_PREFILTRO = cee_rlve3_pci6221_P.Const2_Value;
  } else if (cee_rlve3_pci6221_P.SwitchFiltro_CurrentSetting == 1) {
    /* ManualSwitch: '<Root>/Switch  Filtro' incorporates:
     *  TransferFcn: '<Root>/Filtro'
     */
    rtb_PREFILTRO = cee_rlve3_pci6221_P.Filtro_C[0] *
      cee_rlve3_pci6221_X.Filtro_CSTATE[0] + cee_rlve3_pci6221_P.Filtro_C[1] *
      cee_rlve3_pci6221_X.Filtro_CSTATE[1];
  } else {
    rtb_PREFILTRO = cee_rlve3_pci6221_B.GanhoCalibGage;
  }

  /* End of ManualSwitch: '<Root>/Switch Extensometro' */

  /* Sum: '<Root>/Sum1' incorporates:
   *  Sum: '<Root>/Sum2'
   */
  cee_rlve3_pci6221_B.Sum1 = cee_rlve3_pci6221_B.SwitchPreFiltro -
    (cee_rlve3_pci6221_B.GanhoCalibPot + rtb_PREFILTRO);

  /* Clock: '<Root>/Clock' */
  cee_rlve3_pci6221_B.Clock = cee_rlve3_pci6221_M->Timing.t[0];
  if (rtmIsMajorTimeStep(cee_rlve3_pci6221_M)) {
  }
}

/* Model update function */
void cee_rlve3_pci6221_update(void)
{
  if (rtmIsMajorTimeStep(cee_rlve3_pci6221_M)) {
    rt_ertODEUpdateContinuousStates(&cee_rlve3_pci6221_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++cee_rlve3_pci6221_M->Timing.clockTick0)) {
    ++cee_rlve3_pci6221_M->Timing.clockTickH0;
  }

  cee_rlve3_pci6221_M->Timing.t[0] = rtsiGetSolverStopTime
    (&cee_rlve3_pci6221_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++cee_rlve3_pci6221_M->Timing.clockTick1)) {
      ++cee_rlve3_pci6221_M->Timing.clockTickH1;
    }

    cee_rlve3_pci6221_M->Timing.t[1] = cee_rlve3_pci6221_M->Timing.clockTick1 *
      cee_rlve3_pci6221_M->Timing.stepSize1 +
      cee_rlve3_pci6221_M->Timing.clockTickH1 *
      cee_rlve3_pci6221_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void cee_rlve3_pci6221_derivatives(void)
{
  int_T is;
  int_T ci;
  int_T ci_0;
  XDot_cee_rlve3_pci6221_T *_rtXdot;
  _rtXdot = ((XDot_cee_rlve3_pci6221_T *) cee_rlve3_pci6221_M->ModelData.derivs);

  /* Derivatives for StateSpace: '<Root>/CONTROLADOR' */
  for (is = 0; is < 5; is++) {
    _rtXdot->CONTROLADOR_CSTATE[is] = 0.0;
    for (ci = 0; ci < 5; ci++) {
      ci_0 = ci * 5 + is;
      _rtXdot->CONTROLADOR_CSTATE[is] += ((cee_rlve3_pci6221_P.A2[ci_0] -
        cee_rlve3_pci6221_ConstP.CONTROLADOR_rtw_coll[ci_0]) -
        cee_rlve3_pci6221_ConstP.CONTROLADOR_rtw_co_h[ci_0]) *
        cee_rlve3_pci6221_X.CONTROLADOR_CSTATE[ci];
    }

    _rtXdot->CONTROLADOR_CSTATE[is] += -cee_rlve3_pci6221_P.L[is] *
      cee_rlve3_pci6221_B.Integrator;
  }

  /* End of Derivatives for StateSpace: '<Root>/CONTROLADOR' */

  /* Derivatives for TransferFcn: '<Root>/PRE FILTRO' */
  _rtXdot->PREFILTRO_CSTATE[0] = 0.0;
  _rtXdot->PREFILTRO_CSTATE[1] = 0.0;
  _rtXdot->PREFILTRO_CSTATE[0] += cee_rlve3_pci6221_P.PREFILTRO_A[0] *
    cee_rlve3_pci6221_X.PREFILTRO_CSTATE[0];
  _rtXdot->PREFILTRO_CSTATE[0] += cee_rlve3_pci6221_P.PREFILTRO_A[1] *
    cee_rlve3_pci6221_X.PREFILTRO_CSTATE[1];
  _rtXdot->PREFILTRO_CSTATE[1] += cee_rlve3_pci6221_X.PREFILTRO_CSTATE[0];
  _rtXdot->PREFILTRO_CSTATE[0] += cee_rlve3_pci6221_B.Radianos;

  /* Derivatives for TransferFcn: '<Root>/Filtro' */
  _rtXdot->Filtro_CSTATE[0] = 0.0;
  _rtXdot->Filtro_CSTATE[1] = 0.0;
  _rtXdot->Filtro_CSTATE[0] += cee_rlve3_pci6221_P.Filtro_A[0] *
    cee_rlve3_pci6221_X.Filtro_CSTATE[0];
  _rtXdot->Filtro_CSTATE[0] += cee_rlve3_pci6221_P.Filtro_A[1] *
    cee_rlve3_pci6221_X.Filtro_CSTATE[1];
  _rtXdot->Filtro_CSTATE[1] += cee_rlve3_pci6221_X.Filtro_CSTATE[0];
  _rtXdot->Filtro_CSTATE[0] += cee_rlve3_pci6221_B.GanhoCalibGage;

  /* Derivatives for Integrator: '<Root>/Integrator' */
  _rtXdot->Integrator_CSTATE = cee_rlve3_pci6221_B.Sum1;
}

/* Model initialize function */
void cee_rlve3_pci6221_initialize(void)
{
  /* S-Function Block: <Root>/Tensao Motor */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) cee_rlve3_pci6221_P.TensaoMotor_RangeMode;
      parm.rangeidx = cee_rlve3_pci6221_P.TensaoMotor_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &cee_rlve3_pci6221_P.TensaoMotor_Channels,
                     &cee_rlve3_pci6221_P.TensaoMotor_InitialValue, &parm);
    }
  }

  {
    int_T is;

    /* InitializeConditions for StateSpace: '<Root>/CONTROLADOR' */
    for (is = 0; is < 5; is++) {
      cee_rlve3_pci6221_X.CONTROLADOR_CSTATE[is] =
        cee_rlve3_pci6221_P.CONTROLADOR_X0;
    }

    /* End of InitializeConditions for StateSpace: '<Root>/CONTROLADOR' */

    /* InitializeConditions for TransferFcn: '<Root>/PRE FILTRO' */
    cee_rlve3_pci6221_X.PREFILTRO_CSTATE[0] = 0.0;
    cee_rlve3_pci6221_X.PREFILTRO_CSTATE[1] = 0.0;

    /* InitializeConditions for TransferFcn: '<Root>/Filtro' */
    cee_rlve3_pci6221_X.Filtro_CSTATE[0] = 0.0;
    cee_rlve3_pci6221_X.Filtro_CSTATE[1] = 0.0;

    /* InitializeConditions for Integrator: '<Root>/Integrator' */
    cee_rlve3_pci6221_X.Integrator_CSTATE = cee_rlve3_pci6221_P.Integrator_IC;
  }
}

/* Model terminate function */
void cee_rlve3_pci6221_terminate(void)
{
  /* S-Function Block: <Root>/Tensao Motor */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) cee_rlve3_pci6221_P.TensaoMotor_RangeMode;
      parm.rangeidx = cee_rlve3_pci6221_P.TensaoMotor_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &cee_rlve3_pci6221_P.TensaoMotor_Channels,
                     &cee_rlve3_pci6221_P.TensaoMotor_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  cee_rlve3_pci6221_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  cee_rlve3_pci6221_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  cee_rlve3_pci6221_initialize();
}

void MdlTerminate(void)
{
  cee_rlve3_pci6221_terminate();
}

/* Registration function */
RT_MODEL_cee_rlve3_pci6221_T *cee_rlve3_pci6221(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)cee_rlve3_pci6221_M, 0,
                sizeof(RT_MODEL_cee_rlve3_pci6221_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&cee_rlve3_pci6221_M->solverInfo,
                          &cee_rlve3_pci6221_M->Timing.simTimeStep);
    rtsiSetTPtr(&cee_rlve3_pci6221_M->solverInfo, &rtmGetTPtr
                (cee_rlve3_pci6221_M));
    rtsiSetStepSizePtr(&cee_rlve3_pci6221_M->solverInfo,
                       &cee_rlve3_pci6221_M->Timing.stepSize0);
    rtsiSetdXPtr(&cee_rlve3_pci6221_M->solverInfo,
                 &cee_rlve3_pci6221_M->ModelData.derivs);
    rtsiSetContStatesPtr(&cee_rlve3_pci6221_M->solverInfo, (real_T **)
                         &cee_rlve3_pci6221_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&cee_rlve3_pci6221_M->solverInfo,
      &cee_rlve3_pci6221_M->Sizes.numContStates);
    rtsiSetErrorStatusPtr(&cee_rlve3_pci6221_M->solverInfo, (&rtmGetErrorStatus
      (cee_rlve3_pci6221_M)));
    rtsiSetRTModelPtr(&cee_rlve3_pci6221_M->solverInfo, cee_rlve3_pci6221_M);
  }

  rtsiSetSimTimeStep(&cee_rlve3_pci6221_M->solverInfo, MAJOR_TIME_STEP);
  cee_rlve3_pci6221_M->ModelData.intgData.y =
    cee_rlve3_pci6221_M->ModelData.odeY;
  cee_rlve3_pci6221_M->ModelData.intgData.f[0] =
    cee_rlve3_pci6221_M->ModelData.odeF[0];
  cee_rlve3_pci6221_M->ModelData.intgData.f[1] =
    cee_rlve3_pci6221_M->ModelData.odeF[1];
  cee_rlve3_pci6221_M->ModelData.intgData.f[2] =
    cee_rlve3_pci6221_M->ModelData.odeF[2];
  cee_rlve3_pci6221_M->ModelData.contStates = ((real_T *) &cee_rlve3_pci6221_X);
  rtsiSetSolverData(&cee_rlve3_pci6221_M->solverInfo, (void *)
                    &cee_rlve3_pci6221_M->ModelData.intgData);
  rtsiSetSolverName(&cee_rlve3_pci6221_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = cee_rlve3_pci6221_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    cee_rlve3_pci6221_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    cee_rlve3_pci6221_M->Timing.sampleTimes =
      (&cee_rlve3_pci6221_M->Timing.sampleTimesArray[0]);
    cee_rlve3_pci6221_M->Timing.offsetTimes =
      (&cee_rlve3_pci6221_M->Timing.offsetTimesArray[0]);

    /* task periods */
    cee_rlve3_pci6221_M->Timing.sampleTimes[0] = (0.0);
    cee_rlve3_pci6221_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    cee_rlve3_pci6221_M->Timing.offsetTimes[0] = (0.0);
    cee_rlve3_pci6221_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(cee_rlve3_pci6221_M, &cee_rlve3_pci6221_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = cee_rlve3_pci6221_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    cee_rlve3_pci6221_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(cee_rlve3_pci6221_M, 20.0);
  cee_rlve3_pci6221_M->Timing.stepSize0 = 0.001;
  cee_rlve3_pci6221_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  cee_rlve3_pci6221_M->Sizes.checksums[0] = (3507342379U);
  cee_rlve3_pci6221_M->Sizes.checksums[1] = (1416938852U);
  cee_rlve3_pci6221_M->Sizes.checksums[2] = (23485530U);
  cee_rlve3_pci6221_M->Sizes.checksums[3] = (1780996771U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    cee_rlve3_pci6221_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(cee_rlve3_pci6221_M->extModeInfo,
      &cee_rlve3_pci6221_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(cee_rlve3_pci6221_M->extModeInfo,
                        cee_rlve3_pci6221_M->Sizes.checksums);
    rteiSetTPtr(cee_rlve3_pci6221_M->extModeInfo, rtmGetTPtr(cee_rlve3_pci6221_M));
  }

  cee_rlve3_pci6221_M->solverInfoPtr = (&cee_rlve3_pci6221_M->solverInfo);
  cee_rlve3_pci6221_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&cee_rlve3_pci6221_M->solverInfo, 0.001);
  rtsiSetSolverMode(&cee_rlve3_pci6221_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  cee_rlve3_pci6221_M->ModelData.blockIO = ((void *) &cee_rlve3_pci6221_B);

  {
    cee_rlve3_pci6221_B.Saturation = 0.0;
    cee_rlve3_pci6221_B.SwitchOutput = 0.0;
    cee_rlve3_pci6221_B.GanhoCalibGage = 0.0;
    cee_rlve3_pci6221_B.GanhoCalibPot = 0.0;
    cee_rlve3_pci6221_B.Radianos = 0.0;
    cee_rlve3_pci6221_B.SwitchPreFiltro = 0.0;
    cee_rlve3_pci6221_B.Integrator = 0.0;
    cee_rlve3_pci6221_B.Sum1 = 0.0;
    cee_rlve3_pci6221_B.Clock = 0.0;
  }

  /* parameters */
  cee_rlve3_pci6221_M->ModelData.defaultParam = ((real_T *)&cee_rlve3_pci6221_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &cee_rlve3_pci6221_X;
    cee_rlve3_pci6221_M->ModelData.contStates = (x);
    (void) memset((void *)&cee_rlve3_pci6221_X, 0,
                  sizeof(X_cee_rlve3_pci6221_T));
  }

  /* states (dwork) */
  cee_rlve3_pci6221_M->ModelData.dwork = ((void *) &cee_rlve3_pci6221_DW);
  (void) memset((void *)&cee_rlve3_pci6221_DW, 0,
                sizeof(DW_cee_rlve3_pci6221_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    cee_rlve3_pci6221_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Initialize Sizes */
  cee_rlve3_pci6221_M->Sizes.numContStates = (10);/* Number of continuous states */
  cee_rlve3_pci6221_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  cee_rlve3_pci6221_M->Sizes.numY = (0);/* Number of model outputs */
  cee_rlve3_pci6221_M->Sizes.numU = (0);/* Number of model inputs */
  cee_rlve3_pci6221_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  cee_rlve3_pci6221_M->Sizes.numSampTimes = (2);/* Number of sample times */
  cee_rlve3_pci6221_M->Sizes.numBlocks = (30);/* Number of blocks */
  cee_rlve3_pci6221_M->Sizes.numBlockIO = (9);/* Number of block outputs */
  cee_rlve3_pci6221_M->Sizes.numBlockPrms = (73);/* Sum of parameter "widths" */
  return cee_rlve3_pci6221_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
