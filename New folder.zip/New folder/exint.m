A=[0 0 1 0; 0 0 0 1; 0 566 -37 0; 0 -922 37 0];
b=[0 0 65 -65]';
c=[1 1 0 0];

A2=[A b;0 0 0 0 0];
b2=[zeros(4,1); 1];
c2=[c 0];

%alphaK=poly([-100 -70 -20 -30 -50])
%alphaL=poly([-20 -50 -30 -10 -10])
alphaK=poly([-70 -20 -10 -10 -50])
alphaL=poly([-50 -50 -30 -30 -30])
a=poly(A2)

CM=controlability(A2,b2);
OM=observability(A2,c2);
M=[1 0 0 0 0; 
    a(2) 1 0 0 0; 
    a(3) a(2) 1 0 0; 
    a(4) a(3) a(2) 1 0; 
    a(5) a(4) a(3) a(2) 1];
size(M)
K=(alphaK(2:6)-a(2:6))*inv(M)'*inv(CM)
L=inv(OM)*inv(M)*(alphaL(2:6)-a(2:6))'