A=[0 0 1 0; 0 0 0 1; 0 566 -37 0; 0 -922 37 0];
c=[1 1 0 0];
observe=observability(A,c);