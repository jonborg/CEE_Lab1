% Matlab equation file: "eqn_SRV02_Flexible_Joint.m"
% State-Space Matrices: A, B, C, and D
% for the Quanser SRV02 Rotary Flexible Joint Experiment.

A( 1, 1 ) = 0;
A( 1, 2 ) = 0;
A( 1, 3 ) = 1;
A( 1, 4 ) = 0;
A( 2, 1 ) = 0;
A( 2, 2 ) = 0;
A( 2, 3 ) = 0;
A( 2, 4 ) = 1;
A( 3, 1 ) = 0;
A( 3, 2 ) = K_Stiff/Jeq;
A( 3, 3 ) = -(Eff_M*Eff_G*Kt*Kg^2*Km+Beq*Rm)/Jeq/Rm;
A( 3, 4 ) = 0;
A( 4, 1 ) = 0;
A( 4, 2 ) = -K_Stiff*(Jeq+Jarm)/Jeq/Jarm;
A( 4, 3 ) = (Eff_M*Eff_G*Kt*Kg^2*Km+Beq*Rm)/Jeq/Rm;
A( 4, 4 ) = 0;

B( 1, 1 ) = 0;
B( 2, 1 ) = 0;
B( 3, 1 ) = Eff_M*Eff_G*Kt*Kg/Jeq/Rm;
B( 4, 1 ) = -Eff_M*Eff_G*Kt*Kg/Jeq/Rm;

C( 1, 1 ) = 1;
C( 1, 2 ) = 0;
C( 1, 3 ) = 0;
C( 1, 4 ) = 0;
C( 2, 1 ) = 0;
C( 2, 2 ) = 1;
C( 2, 3 ) = 0;
C( 2, 4 ) = 0;

D( 1, 1 ) = 0;
D( 2, 1 ) = 0;
