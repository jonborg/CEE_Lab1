/*
 * cee_rlve2_pci6221_data.c
 *
 * Code generation for model "cee_rlve2_pci6221".
 *
 * Model version              : 1.19
 * Simulink Coder version : 8.8 (R2015a) 09-Feb-2015
 * C source code generated on : Wed Mar 30 18:20:36 2016
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Real-Time Windows Target
 * Emulation hardware selection:
 *    Differs from embedded hardware (32-bit Generic)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "cee_rlve2_pci6221.h"
#include "cee_rlve2_pci6221_private.h"

/* Block parameters (auto storage) */
P_cee_rlve2_pci6221_T cee_rlve2_pci6221_P = {
  /*  Variable: A
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 566.45969030189679, -921.76544874111357, 1.0,
    0.0, -37.021773156792193, 37.021773156792193, 0.0, 1.0, 0.0, 0.0 },

  /*  Variable: K
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 6.0501296456352733, -30.534485738980152, 1.0297320656871252,
    -0.093344857389798808 },
  0.052631578947368418,                /* Variable: K_GAGE
                                        * Referenced by: '<Root>/Ganho Calib Gage'
                                        */
  -0.614355896702004,                  /* Variable: K_POT
                                        * Referenced by: '<Root>/Ganho Calib Pot'
                                        */

  /*  Variable: L
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 33.457865168539684, 89.542134831460316, -1161.2050561797805,
    5088.2050561797832 },
  0.0,                                 /* Mask Parameter: TensaoMotor_FinalValue
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  0.0,                                 /* Mask Parameter: TensaoMotor_InitialValue
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  10.0,                                /* Mask Parameter: TensaoMotor_MaxMissedTicks
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  10.0,                                /* Mask Parameter: Extensometro_MaxMissedTicks
                                        * Referenced by: '<Root>/Extensometro'
                                        */
  10.0,                                /* Mask Parameter: Potenciometro_MaxMissedTicks
                                        * Referenced by: '<Root>/Potenciometro'
                                        */
  0.0,                                 /* Mask Parameter: TensaoMotor_YieldWhenWaiting
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  0.0,                                 /* Mask Parameter: Extensometro_YieldWhenWaiting
                                        * Referenced by: '<Root>/Extensometro'
                                        */
  0.0,                                 /* Mask Parameter: Potenciometro_YieldWhenWaiting
                                        * Referenced by: '<Root>/Potenciometro'
                                        */
  0,                                   /* Mask Parameter: TensaoMotor_Channels
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  1,                                   /* Mask Parameter: Extensometro_Channels
                                        * Referenced by: '<Root>/Extensometro'
                                        */
  0,                                   /* Mask Parameter: Potenciometro_Channels
                                        * Referenced by: '<Root>/Potenciometro'
                                        */
  0,                                   /* Mask Parameter: TensaoMotor_RangeMode
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  0,                                   /* Mask Parameter: Extensometro_RangeMode
                                        * Referenced by: '<Root>/Extensometro'
                                        */
  0,                                   /* Mask Parameter: Potenciometro_RangeMode
                                        * Referenced by: '<Root>/Potenciometro'
                                        */
  0,                                   /* Mask Parameter: TensaoMotor_VoltRange
                                        * Referenced by: '<Root>/Tensao Motor'
                                        */
  0,                                   /* Mask Parameter: Extensometro_VoltRange
                                        * Referenced by: '<Root>/Extensometro'
                                        */
  0,                                   /* Mask Parameter: Potenciometro_VoltRange
                                        * Referenced by: '<Root>/Potenciometro'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/CONTROLADOR'
                                        */
  5.0,                                 /* Expression: 5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  -5.0,                                /* Expression: -5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Constant'
                                        */

  /*  Computed Parameter: PREFILTRO_A
   * Referenced by: '<Root>/PRE FILTRO'
   */
  { -14.0, -49.0 },

  /*  Computed Parameter: PREFILTRO_C
   * Referenced by: '<Root>/PRE FILTRO'
   */
  { 0.0, 52.92 },
  30.0,                                /* Expression: 30
                                        * Referenced by: '<Root>/referencia'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<Root>/referencia'
                                        */
  0.017453292519943295,                /* Expression: pi/180
                                        * Referenced by: '<Root>/Radianos'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Const2'
                                        */

  /*  Computed Parameter: Filtro_A
   * Referenced by: '<Root>/Filtro'
   */
  { -40.0, -400.0 },

  /*  Computed Parameter: Filtro_C
   * Referenced by: '<Root>/Filtro'
   */
  { 0.0, 400.0 },
  0U,                                  /* Computed Parameter: SwitchFiltro_CurrentSetting
                                        * Referenced by: '<Root>/Switch  Filtro'
                                        */
  1U,                                  /* Computed Parameter: SwitchOutput_CurrentSetting
                                        * Referenced by: '<Root>/Switch Output'
                                        */
  0U,                                  /* Computed Parameter: SwitchPreFiltro_CurrentSetting
                                        * Referenced by: '<Root>/Switch  Pre-Filtro'
                                        */
  0U                                   /* Computed Parameter: SwitchExtensometro_CurrentSetti
                                        * Referenced by: '<Root>/Switch Extensometro'
                                        */
};

/* Constant parameters (auto storage) */
const ConstP_cee_rlve2_pci6221_T cee_rlve2_pci6221_ConstP = {
  /* Expression: A-B*K-L*C
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 0.0, 0.0, 393.94428682781495, -393.94428682781495, 0.0, 0.0,
    -1988.2030489668241, 1988.2030489668241, 0.0, 0.0, 67.049317618094207,
    -67.049317618094207, 0.0, 0.0, -6.0779975682004075, 6.0779975682004075 },

  /* Expression: A-B*K-L*C
   * Referenced by: '<Root>/CONTROLADOR'
   */
  { 33.457865168539684, 89.542134831460316, -1161.2050561797805,
    5088.2050561797832, 33.457865168539684, 89.542134831460316,
    -1161.2050561797805, 5088.2050561797832, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0 }
};
