/*
 * cee_rlve2_pci6221_types.h
 *
 * Code generation for model "cee_rlve2_pci6221".
 *
 * Model version              : 1.19
 * Simulink Coder version : 8.8 (R2015a) 09-Feb-2015
 * C source code generated on : Wed Mar 30 18:20:36 2016
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Real-Time Windows Target
 * Emulation hardware selection:
 *    Differs from embedded hardware (32-bit Generic)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_cee_rlve2_pci6221_types_h_
#define RTW_HEADER_cee_rlve2_pci6221_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"

/* Parameters (auto storage) */
typedef struct P_cee_rlve2_pci6221_T_ P_cee_rlve2_pci6221_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_cee_rlve2_pci6221_T RT_MODEL_cee_rlve2_pci6221_T;

#endif                                 /* RTW_HEADER_cee_rlve2_pci6221_types_h_ */
